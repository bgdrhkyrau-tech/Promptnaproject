export type CardVariable = { key: string; labelAr: string; labelEn: string; defaultValue: string; descriptionAr: string; descriptionEn: string };
export type PromptCard = {
  id: string;
  titleAr: string;
  titleEn: string;
  categoryAr: string;
  categoryEn: string;
  audienceAr: string;
  audienceEn: string;
  summaryAr: string;
  summaryEn: string;
  image: string;
  approved: boolean;
  sourceIds: number[];
  promptAr: string;
  promptEn: string;
  variables: CardVariable[];
  stepsAr: string[];
  stepsEn: string[];
  limitationsAr: string;
  limitationsEn: string;
};

// This is intentionally the only seed card until the review workflow supplies verified topics.
export const cards: PromptCard[] = [
  {
    id: "verified-001",
    titleAr: "لوحة أعمال مرئية لمنتج رقمي",
    titleEn: "Visual Workboard for a Digital Product",
    categoryAr: "عرض الأعمال والواجهات",
    categoryEn: "Portfolio & Interface Showcase",
    audienceAr: "المصممون وأصحاب المنتجات",
    audienceEn: "Designers and product teams",
    summaryAr: "استلهام موثق من إطار الفيديو الأول: تجميع نتائج تصميمية متعددة في لوحة عرض عمودية تساعد العميل على فهم تنوع المخرجات قبل كتابة البرومبت.",
    summaryEn: "Verified inspiration from the first reviewed frame: arrange multiple design outcomes in a vertical showcase so the viewer understands the range before writing a prompt.",
    image: "/manus-storage/async-images/UWu2NMxyoz9u2eIiSjRAoG/image-1.webp",
    approved: false,
    sourceIds: [1],
    promptAr: "أنشئ لوحة عرض عمودية متماسكة لنتائج تصميمية متعددة لمنتج رقمي باسم [اسم المنتج]، تشمل [عدد النتائج] وحدات مختلفة: لقطة واجهة، تطبيق هوية، بطاقة منتج، وتكوين تحريري. اجعل كل وحدة واضحة ومستقلة مع نظام شبكي مشترك، خلفية فحمية، إضاءة ناعمة، مساحات تنفس، ونصوص تجريبية قصيرة غير ادعائية. حافظ على اتساق الألوان [لوحة الألوان] واتجاه بصري واحد، واجعل التكوين مناسبًا للعرض العمودي بنسبة 9:16. لا تستخدم أشخاصًا أو علامات تجارية حقيقية أو شعارات غير مطلوبة، ولا تضف أسعارًا أو ادعاءات.",
    promptEn: "Create a cohesive vertical showcase board for multiple design outcomes for a digital product called [product name], containing [number of outcomes] distinct units: an interface view, a brand application, a product card, and an editorial composition. Give each unit a clear boundary while keeping a shared grid, charcoal background, soft studio lighting, breathing room, and short non-claiming placeholder copy. Keep the palette consistent with [color palette] and the visual direction coherent, formatted for a 9:16 vertical presentation. Do not use people, real brands, unrequested logos, prices, or product claims.",
    variables: [
      { key: "productName", labelAr: "اسم المنتج", labelEn: "Product name", defaultValue: "NOVA", descriptionAr: "يغير اسم المشروع داخل اللوحة.", descriptionEn: "Changes the project name shown in the board." },
      { key: "numberOfOutcomes", labelAr: "عدد النتائج", labelEn: "Number of outcomes", defaultValue: "4", descriptionAr: "يحدد كثافة اللوحة وعدد الوحدات.", descriptionEn: "Controls the board density and number of units." },
      { key: "colorPalette", labelAr: "لوحة الألوان", labelEn: "Color palette", defaultValue: "navy, apricot, warm white", descriptionAr: "يغير المزاج اللوني مع الحفاظ على الاتساق.", descriptionEn: "Changes the color mood while preserving consistency." }
    ],
    stepsAr: ["استبدل المتغيرات بين الأقواس بقيم مشروعك.", "حدّد نوع النتائج التي تريد عرضها بدل إضافة وحدات عامة.", "استخدم صورة اللوحة كمرجع بصري، ثم راجع النصوص إذا احتجت دقة طباعية."],
    stepsEn: ["Replace the bracketed variables with your project values.", "Specify the outcomes you need instead of adding generic units.", "Use the board as a visual reference, then inspect text if typographic accuracy matters."],
    limitationsAr: "النصوص الصغيرة والشعارات الدقيقة تعتمد على أداة التوليد؛ هذه البطاقة استلهام موثق وليست ادعاءً بأن الفيديو الأصلي أنتج هذه الصياغة حرفيًا.",
    limitationsEn: "Small text and exact logos depend on the image tool; this card is documented inspiration, not a claim that the original video produced this exact wording.",
  }
];
