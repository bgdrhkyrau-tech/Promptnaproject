export default { logoUrl: "https://placehold.co/256x256/f26b4f/ffffff.png?text=P" };
