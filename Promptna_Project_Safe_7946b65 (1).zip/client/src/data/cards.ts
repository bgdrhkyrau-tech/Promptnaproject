export type CardVariable = { key: string; labelAr: string; labelEn: string; defaultValue: string; descriptionAr: string; descriptionEn: string };
export type PromptCard = {
  id: string;
  titleAr: string;
  titleEn: string;
  categoryAr: string;
  categoryEn: string;
  audienceAr: string;
  audienceEn: string;
  summaryAr: string;
  summaryEn: string;
  image: string;
  approved: boolean;
  sourceIds: number[];
  promptAr: string;
  promptEn: string;
  variables: CardVariable[];
  stepsAr: string[];
  stepsEn: string[];
  limitationsAr: string;
  limitationsEn: string;
  imageStatus?: "verified" | "experimental" | "missing";
  imageNoteAr?: string;
  imageNoteEn?: string;
};

// Only one experimental image is currently available. The other records are explicit drafts
// derived from visually reviewed sources and must not be counted as complete until matched images pass licensing and visual review.
export const cards: PromptCard[] = [
  {
    id: "verified-001",
    titleAr: "لوحة أعمال مرئية لمنتج رقمي",
    titleEn: "Visual Workboard for a Digital Product",
    categoryAr: "عرض الأعمال والواجهات",
    categoryEn: "Portfolio & Interface Showcase",
    audienceAr: "المصممون وأصحاب المنتجات",
    audienceEn: "Designers and product teams",
    summaryAr: "استلهام موثق من إطار الفيديو الأول: تجميع نتائج تصميمية متعددة في لوحة عرض عمودية تساعد العميل على فهم تنوع المخرجات قبل كتابة البرومبت.",
    summaryEn: "Verified inspiration from the first reviewed frame: arrange multiple design outcomes in a vertical showcase so the viewer understands the range before writing a prompt.",
    image: "/manus-storage/async-images/UWu2NMxyoz9u2eIiSjRAoG/image-1.webp",
    approved: false,
    imageStatus: "experimental",
    imageNoteAr: "الصورة اختبارية فقط وليست أصلًا نهائيًا معتمدًا.",
    imageNoteEn: "This is an experimental image, not a final approved asset.",
    sourceIds: [1],
    promptAr: "أنشئ لوحة عرض عمودية متماسكة لنتائج تصميمية متعددة لمنتج رقمي باسم [اسم المنتج]، تشمل [عدد النتائج] وحدات مختلفة: لقطة واجهة، تطبيق هوية، بطاقة منتج، وتكوين تحريري. اجعل كل وحدة واضحة ومستقلة مع نظام شبكي مشترك، خلفية فحمية، إضاءة ناعمة، مساحات تنفس، ونصوص تجريبية قصيرة غير ادعائية. حافظ على اتساق الألوان [لوحة الألوان] واتجاه بصري واحد، واجعل التكوين مناسبًا للعرض العمودي بنسبة 9:16. لا تستخدم أشخاصًا أو علامات تجارية حقيقية أو شعارات غير مطلوبة، ولا تضف أسعارًا أو ادعاءات.",
    promptEn: "Create a cohesive vertical showcase board for multiple design outcomes for a digital product called [product name], containing [number of outcomes] distinct units: an interface view, a brand application, a product card, and an editorial composition. Give each unit a clear boundary while keeping a shared grid, charcoal background, soft studio lighting, breathing room, and short non-claiming placeholder copy. Keep the palette consistent with [color palette] and the visual direction coherent, formatted for a 9:16 vertical presentation. Do not use people, real brands, unrequested logos, prices, or product claims.",
    variables: [
      { key: "productName", labelAr: "اسم المنتج", labelEn: "Product name", defaultValue: "NOVA", descriptionAr: "يغير اسم المشروع داخل اللوحة.", descriptionEn: "Changes the project name shown in the board." },
      { key: "numberOfOutcomes", labelAr: "عدد النتائج", labelEn: "Number of outcomes", defaultValue: "4", descriptionAr: "يحدد كثافة اللوحة وعدد الوحدات.", descriptionEn: "Controls the board density and number of units." },
      { key: "colorPalette", labelAr: "لوحة الألوان", labelEn: "Color palette", defaultValue: "navy, apricot, warm white", descriptionAr: "يغير المزاج اللوني مع الحفاظ على الاتساق.", descriptionEn: "Changes the color mood while preserving consistency." }
    ],
    stepsAr: ["استبدل المتغيرات بين الأقواس بقيم مشروعك.", "حدّد نوع النتائج التي تريد عرضها بدل إضافة وحدات عامة.", "استخدم الصورة كمرجع بصري فقط إلى أن يتم اعتماد أصل نهائي."],
    stepsEn: ["Replace the bracketed variables with your project values.", "Specify the outcomes you need instead of adding generic units.", "Use the image as visual guidance only until a final asset is approved."],
    limitationsAr: "النصوص الصغيرة والشعارات الدقيقة تعتمد على أداة التوليد؛ هذه البطاقة استلهام موثق وليست ادعاءً بأن الفيديو الأصلي أنتج هذه الصياغة حرفيًا.",
    limitationsEn: "Small text and exact logos depend on the image tool; this card is documented inspiration, not a claim that the original video produced this exact wording."
  },
  {
    id: "reviewed-003",
    titleAr: "لوحة إعلانات عمودية متعددة لمنتج واحد",
    titleEn: "Multi-Panel Vertical Ad Board for One Product",
    categoryAr: "إعلانات المنتجات",
    categoryEn: "Product Advertising",
    audienceAr: "فرق التسويق وأصحاب المنتجات",
    audienceEn: "Marketing teams and product owners",
    summaryAr: "مشتقة من المرجع المرئي رقم 3: تحويل صورة العبوة إلى شبكة من ست إلى تسع لوحات إعلانية عمودية متناسقة، مع الحفاظ على شكل المنتج وعدم اختلاق فوائد أو أسعار.",
    summaryEn: "Derived from visually reviewed source 3: turn one package photo into a coherent six-to-nine-panel vertical ad board while preserving the product shape and avoiding invented claims or prices.",
    image: "",
    approved: false,
    imageStatus: "missing",
    imageNoteAr: "تحتاج البطاقة إلى صورة مرخصة ومطابقة قبل اعتمادها.",
    imageNoteEn: "This card needs a licensed, visually matched reference before approval.",
    sourceIds: [3],
    promptAr: "حوّل صورة العبوة المرفقة لمنتج [اسم المنتج] إلى لوحة إعلانات عمودية بنسبة 9:16 تضم [عدد اللوحات] لوحات مختلفة لكن متناسقة. حافظ بدقة على شكل العبوة وألوانها وموضع الشعار الموجود في الصورة من دون إعادة رسم شعار جديد. أنشئ تنويعات تشمل لقطة المنتج منفردًا، لقطة مقربة للتفاصيل، تكوينًا مع مكوّن بصري مرتبط بالمنتج، وتكوينًا تحريريًا نظيفًا. استخدم لوحة ألوان [الألوان] وخلفية [الخلفية] وإضاءة استوديو ناعمة. أضف عناوين قصيرة مكانية فقط، ولا تضف فوائد أو أسعارًا أو ادعاءات غير موجودة في المدخل.",
    promptEn: "Turn the supplied package photo of [product name] into a coherent 9:16 vertical advertising board with [panel count] distinct panels. Preserve the package shape, colors, and any existing logo placement exactly; do not redraw or invent a brand mark. Include variations such as a clean product-only shot, a detail crop, a composition with a product-relevant visual ingredient, and an editorial layout. Use [palette], [background], and soft studio lighting. Add only short placeholder headline areas; do not invent benefits, prices, or claims that are not present in the input.",
    variables: [
      { key: "productName", labelAr: "اسم المنتج", labelEn: "Product name", defaultValue: "منتجي", descriptionAr: "يحدد تسمية المنتج في البرومبت.", descriptionEn: "Sets the product label in the prompt." },
      { key: "panelCount", labelAr: "عدد اللوحات", labelEn: "Panel count", defaultValue: "6", descriptionAr: "يحدد عدد التنويعات في لوحة الإعلان.", descriptionEn: "Controls the number of ad variations." },
      { key: "palette", labelAr: "الألوان", labelEn: "Palette", defaultValue: "orange, warm white, charcoal", descriptionAr: "يحدد المزاج اللوني.", descriptionEn: "Sets the visual color mood." },
      { key: "background", labelAr: "الخلفية", labelEn: "Background", defaultValue: "warm studio surface", descriptionAr: "يحدد سياق التصوير.", descriptionEn: "Sets the photography context." }
    ],
    stepsAr: ["أرفق صورة واضحة للعبوة من دون قص الأجزاء المهمة.", "حدّد عدد اللوحات ولوحة الألوان.", "راجع كل لوحة للتأكد من عدم تغير العبوة أو ظهور ادعاءات جديدة."],
    stepsEn: ["Attach a clear package photo without cropping important parts.", "Set the panel count and palette.", "Inspect every panel for package drift or newly invented claims."],
    limitationsAr: "هذه البطاقة مستمدة من مشهد مرئي، لكن الصورة المطابقة للنتيجة لم تُعتمد بعد. دقة النصوص والشعارات تتطلب مراجعة يدوية.",
    limitationsEn: "This card is derived from a visible scene, but its matched image has not been approved yet. Exact text and logos require manual review."
  },
  {
    id: "reviewed-004",
    titleAr: "لقطة مقرّبة لتفاصيل خامة المنتج",
    titleEn: "Close-Up Product Material Detail",
    categoryAr: "تفاصيل المنتجات والخامات",
    categoryEn: "Product Detail & Material",
    audienceAr: "مصورو المنتجات ومصممو الأزياء",
    audienceEn: "Product photographers and fashion designers",
    summaryAr: "مشتقة من المرجع المرئي رقم 4: الانتقال من صورة قطعة ملابس إلى لقطة عمودية مقرّبة تظهر النسيج والطبعة والحواف من دون تغيير القطعة الأصلية.",
    summaryEn: "Derived from visually reviewed source 4: move from a garment photo to a vertical close-up showing weave, print, and edges without changing the original item.",
    image: "",
    approved: false,
    imageStatus: "missing",
    imageNoteAr: "تحتاج البطاقة إلى صورة خامة مرخصة ومطابقة قبل اعتمادها.",
    imageNoteEn: "This card needs a licensed, visually matched material image before approval.",
    sourceIds: [4],
    promptAr: "أنشئ دراسة تفاصيل عمودية بنسبة 9:16 اعتمادًا على صورة [نوع القطعة] المرفقة. اعرض ثلاث لقطات مترابطة: المشهد الكامل، تكبيرًا واضحًا للنسيج، وتفصيلًا للحافة أو الطبعة. حافظ على اللون والشكل والعيوب الواقعية للقطعة، وأظهر ألياف النسيج والثنيات بإضاءة جانبية ناعمة وخلفية محايدة. اجعل النتيجة مناسبة لعرض جودة الخامة، من دون إضافة جسم أو يد أو شعار غير موجود في الصورة، ومن دون تنعيم مفرط يخفي الملمس.",
    promptEn: "Create a 9:16 vertical material-detail study from the supplied photo of a [garment type]. Show three connected views: the full item, a clear weave close-up, and a detail of the edge or print. Preserve the original color, shape, and realistic imperfections; reveal the fibers and folds with soft side lighting against a neutral background. Make the result suitable for communicating material quality. Do not add a body, hand, or logo that is absent from the input, and do not over-smooth the texture.",
    variables: [
      { key: "garmentType", labelAr: "نوع القطعة", labelEn: "Garment type", defaultValue: "قميص", descriptionAr: "يحدد نوع المنتج المصور.", descriptionEn: "Defines the photographed item." },
      { key: "lighting", labelAr: "الإضاءة", labelEn: "Lighting", defaultValue: "soft side light", descriptionAr: "يغير طريقة إبراز الألياف والثنيات.", descriptionEn: "Changes how fibers and folds are revealed." },
      { key: "background", labelAr: "الخلفية", labelEn: "Background", defaultValue: "neutral warm gray", descriptionAr: "يحدد الخلفية خلف القطعة.", descriptionEn: "Sets the background behind the item." }
    ],
    stepsAr: ["استخدم صورة عالية الدقة للقطعة.", "حدّد نوع الخامة أو اترك الأداة تستنتجه بحذر.", "افحص اللقطات المقربة بحثًا عن ألياف أو طبعات مختلقة."],
    stepsEn: ["Use a high-resolution photo of the item.", "Specify the material or let the tool infer it cautiously.", "Inspect close-ups for invented fibers or prints."],
    limitationsAr: "النتيجة المقربة قد توهم بتفاصيل غير موجودة في المصدر؛ يجب مقارنتها بالصورة الأصلية قبل استخدامها تجاريًا.",
    limitationsEn: "A close-up can hallucinate details that are not in the source; compare it with the original before commercial use."
  },
  {
    id: "reviewed-005",
    titleAr: "حزمة قصص تسويقية عمودية من صورة منتج",
    titleEn: "Vertical Marketing Story Set from One Product Photo",
    categoryAr: "محتوى الشبكات الاجتماعية",
    categoryEn: "Social Media Content",
    audienceAr: "صناع المحتوى وفرق التسويق",
    audienceEn: "Content creators and marketing teams",
    summaryAr: "مشتقة من المرجع المرئي رقم 5: تحويل صورة منتج واحدة إلى مجموعة مشاهد تسويقية عمودية متتابعة مع الحفاظ على هوية العبوة وعدم اختلاق مزاعم.",
    summaryEn: "Derived from visually reviewed source 5: transform one product photo into a sequence of vertical marketing scenes while preserving package identity and avoiding invented claims.",
    image: "",
    approved: false,
    imageStatus: "missing",
    imageNoteAr: "تحتاج البطاقة إلى صورة منتج مرخصة ومطابقة قبل اعتمادها.",
    imageNoteEn: "This card needs a licensed, visually matched product image before approval.",
    sourceIds: [5],
    promptAr: "أنشئ حزمة من [عدد القصص] قصص عمودية بنسبة 9:16 انطلاقًا من صورة المنتج المرفقة. اجعل كل قصة مختلفة في التكوين: المنتج على سطح استخدام، لقطة قريبة للعبوة، تطبيق بصري على عنصر محايد، ولقطة ختامية نظيفة. حافظ على ألوان العبوة وشكلها واتجاه الشعار كما هو، واستخدم خلفية [الأسلوب] وإضاءة [الإضاءة]. اترك مساحة واضحة لنص يضيفه المصمم لاحقًا، ولا تكتب فوائد أو أسعارًا أو عبارات اعتماد غير موجودة في المدخل.",
    promptEn: "Create a set of [story count] 9:16 vertical stories from the supplied product photo. Make each story compositionally distinct: the product in a use context, a package close-up, a neutral branded application, and a clean closing frame. Preserve the package colors, shape, and logo orientation exactly. Use a [style] background and [lighting]. Leave clean space for copy to be added later; do not write benefits, prices, endorsements, or claims that are not present in the input.",
    variables: [
      { key: "storyCount", labelAr: "عدد القصص", labelEn: "Story count", defaultValue: "4", descriptionAr: "يحدد عدد المشاهد العمودية.", descriptionEn: "Sets the number of vertical scenes." },
      { key: "style", labelAr: "الأسلوب", labelEn: "Style", defaultValue: "clean editorial kitchen", descriptionAr: "يحدد البيئة البصرية للمشاهد.", descriptionEn: "Sets the visual environment." },
      { key: "lighting", labelAr: "الإضاءة", labelEn: "Lighting", defaultValue: "soft daylight", descriptionAr: "يحدد إحساس الإضاءة.", descriptionEn: "Sets the lighting mood." }
    ],
    stepsAr: ["أرفق صورة المنتج مع كامل العبوة ظاهرًا.", "حدد عدد القصص والبيئة المناسبة للمنتج.", "أضف النص النهائي يدويًا بعد مراجعة ثبات العبوة في كل مشهد."],
    stepsEn: ["Attach a product photo with the full package visible.", "Set the story count and a relevant environment.", "Add final copy manually after checking package consistency across scenes."],
    limitationsAr: "الصورة النهائية المطابقة لم تُعتمد بعد. الصور التي تحتوي على شعارات أو أشخاص تحتاج تدقيق حقوق إضافي.",
    limitationsEn: "The final matched image has not been approved yet. Images containing logos or people need additional rights review."
  }
];
